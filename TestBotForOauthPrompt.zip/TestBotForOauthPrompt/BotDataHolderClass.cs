﻿using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace EchoBot
{
    public static class BotDataHolderClass
    {
        public const string WelcomeText = "Hi, I am Your Assingment Bot 🤵... !" + "\n" + "Enter your Name to start conversation...";


        public const string ConnectionName = "OAuthConnection";

        public const string LoginPromptName = "loginPrompt";

        public static TokenResponse TokenResponse
        {
            get; set;
        }

        public static string AccessToken { get; set; }


        public static string LoggedinUserID { get; set; }


        public static string listRelatedtologgedinUser { get; set; }
        public static async Task<string> GetLoggedInUserIDFromToken(string token)
        {
            try
            {

                WebRequest req = WebRequest.Create(@"https://graph.microsoft.com/v1.0/me");
                req.Method = "GET";
                req.ContentType = "application/json";
                req.Headers["Authorization"] = "Bearer " + token;

                HttpWebResponse resp = req.GetResponse() as HttpWebResponse;

                StreamReader reader = new StreamReader(resp.GetResponseStream());

                var responseBody = reader.ReadToEnd();

                dynamic dynJson = JsonConvert.DeserializeObject(responseBody);
                string username = dynJson.userPrincipalName.Value.ToString();

                return username;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public static async Task<string> GetLoggedinUserAssingmentList(string username)
        {
            string vrealtedvmslist = string.Empty;
            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();                
                builder.DataSource = "AzureDataSource";//Plcaeholders need to provide correct data
                builder.UserID = "AzureSqlDBUserID";//Plcaeholders need to provide correct data
                builder.Password = "AzureSqlDBPassword";//Plcaeholders need to provide correct data
                builder.InitialCatalog = "AzureSqlDBInitialCatalog";//Plcaeholders need to provide correct data
                SqlConnection connection = new SqlConnection(builder.ConnectionString);
                await connection.OpenAsync();
                string query = string.Format("SELECT AssingmentsList FROM [dbo].[AssignmentTable](nolock) WHERE [UserName] = '{0}'", username);
                SqlCommand command = new SqlCommand(query, connection);
                //int id = Convert.ToInt32(await command.ExecuteScalarAsync());
                //query = string.Format("SELECT [VMName] FROM [dbo].[VMnameandUserRelation](nolock) WHERE [UserID] = '{0}'", id);
                //command = new SqlCommand(query, connection);
                vrealtedvmslist = Convert.ToString(await command.ExecuteScalarAsync());

                connection.Close();
                connection.Dispose();

                return vrealtedvmslist;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return vrealtedvmslist;
            }
        }

    }
}
