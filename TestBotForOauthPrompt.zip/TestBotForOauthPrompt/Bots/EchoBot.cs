// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using EchoBot;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace Microsoft.BotBuilderSamples.Bots
{
    public class EchoBot<T> : ActivityHandler where T : Dialog
    {
        public readonly BotState ConversationState;
        public readonly Dialog Dialog;
        public readonly ILogger Logger;
        public readonly BotState UserState;
        public readonly IConfiguration Configuration;


        public EchoBot(IConfiguration configuration, ConversationState conversationState, UserState userState, T dialog , ILogger<EchoBot<T>> logger)
        {
            Configuration = configuration;
            ConversationState = conversationState;
            UserState = userState;
            Dialog = dialog;         
            Logger = logger;
        }

        public override async Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken = default(CancellationToken))
        {
            if (turnContext.Activity.Name == "webchat/join")
            {
                await turnContext.SendActivityAsync(MessageFactory.Text(BotDataHolderClass.WelcomeText), cancellationToken);
            }
            await base.OnTurnAsync(turnContext, cancellationToken);
            
            // Save any state changes that might have occured during the turn.
            await ConversationState.SaveChangesAsync(turnContext, false, cancellationToken);
            await UserState.SaveChangesAsync(turnContext, false, cancellationToken);
            

        }
        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {            
            Logger.LogInformation("Running dialog with Message Activity.");

            // Run the Dialog with the new message Activity.
            await Dialog.Run(turnContext, ConversationState.CreateProperty<DialogState>(nameof(DialogState)), cancellationToken);
        }

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    await turnContext.SendActivityAsync(MessageFactory.Text($"Hello and welcome! Please type any thing to continue"), cancellationToken);
                }
            }
        }
    }
}
