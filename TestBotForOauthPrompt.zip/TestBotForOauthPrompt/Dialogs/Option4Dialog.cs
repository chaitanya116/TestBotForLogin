﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EchoBot.Dialogs
{
    public class Option4Dialog : WaterfallDialog
    {
        public Option4Dialog(string dialogId, IEnumerable<WaterfallStep> steps = null)
           : base(dialogId, steps)
        {
            AddStep(async (stepContext, cancellationToken) =>
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Selected option 4"));
                return await stepContext.EndDialogAsync();
            });
        }
        public static new string Id => "Option4Dialog";

        public static Option4Dialog Instance { get; } = new Option4Dialog(Id);
    }
}