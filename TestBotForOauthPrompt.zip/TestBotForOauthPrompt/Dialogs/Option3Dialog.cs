﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EchoBot.Dialogs
{
    public class Option3Dialog : WaterfallDialog
    {
        public Option3Dialog(string dialogId, IEnumerable<WaterfallStep> steps = null)
           : base(dialogId, steps)
        {
            AddStep(async (stepContext, cancellationToken) =>
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Selected option 3"));
                return await stepContext.EndDialogAsync();
            });
        }
        public static new string Id => "Option3Dialog";

        public static Option3Dialog Instance { get; } = new Option3Dialog(Id);
    }
}
