﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EchoBot.Dialogs
{
    public class LogOutDialog : WaterfallDialog
    {
        public LogOutDialog(string dialogId, IEnumerable<WaterfallStep> steps = null)
            : base(dialogId, steps)
        {
            AddStep(async (stepContext, cancellationToken) =>
            {
                var botAdapter = (BotFrameworkAdapter)stepContext.Context.Adapter;
                await botAdapter.SignOutUserAsync(stepContext.Context, BotDataHolderClass.ConnectionName, null, cancellationToken);
                BotDataHolderClass.TokenResponse = null;
                BotDataHolderClass.LoggedinUserID = string.Empty;               
                await stepContext.Context.SendActivityAsync(MessageFactory.Text($"You have been loggged out successfully"));

                return await stepContext.BeginDialogAsync(LoginDialog.Id, cancellationToken: cancellationToken);
            });
        }
        public static new string Id => "LogOutDialog";

        public static LogOutDialog Instance { get; } = new LogOutDialog(Id);
    }
}
