﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EchoBot.Dialogs
{
    public class LoginDialog : WaterfallDialog
    {
        public LoginDialog(string dialogId, IEnumerable<WaterfallStep> steps = null)
           : base(dialogId, steps)
        {
            AddStep(async (stepContext, cancellationToken) =>
            {
                return await stepContext.BeginDialogAsync(BotDataHolderClass.LoginPromptName, cancellationToken: cancellationToken); // This actually calls the  dialogue of OAuthPrompt whose name is  in EchoWithCounterBot.LoginPromptName.  

            });

            AddStep(async (stepContext, cancellationToken) =>
            {
                var response = stepContext.Result.ToString();

                BotDataHolderClass.TokenResponse = (TokenResponse)stepContext.Result;

                if (BotDataHolderClass.TokenResponse != null)
                {
                    BotDataHolderClass.LoggedinUserID = await BotDataHolderClass.GetLoggedInUserIDFromToken(BotDataHolderClass.TokenResponse.Token);
                    var loginid = BotDataHolderClass.LoggedinUserID.Split('@');
                    var userid = loginid[0];
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Logged in Successfully with {userid}"));

                    BotDataHolderClass.listRelatedtologgedinUser = await BotDataHolderClass.GetLoggedinUserAssingmentList(BotDataHolderClass.LoggedinUserID);
                    return await stepContext.BeginDialogAsync(DisplayOptionsDialog.Id, cancellationToken: cancellationToken);

                }
                else
                {
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Sorry, Login failed. No worries, you can still continue trying to logging in again..."));

                    var botAdapter = (BotFrameworkAdapter)stepContext.Context.Adapter;
                    await botAdapter.SignOutUserAsync(stepContext.Context, BotDataHolderClass.ConnectionName, null, cancellationToken);
                    BotDataHolderClass.TokenResponse = null;
                    BotDataHolderClass.LoggedinUserID = string.Empty;
                    return await stepContext.BeginDialogAsync(Id, cancellationToken: cancellationToken);

                }
            });
        }

        public static new string Id => "LoginDialog";

        public static LoginDialog Instance { get; } = new LoginDialog(Id);
    }
}
