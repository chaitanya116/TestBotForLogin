﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace EchoBot.Dialogs
{
    public class Option2Dialog : WaterfallDialog
    {
        public Option2Dialog(string dialogId, IEnumerable<WaterfallStep> steps = null)
            : base(dialogId, steps)
        {
            string[] vmarraylist = new string[0];
            var choices = new List<Choice>();
            AddStep(async (stepContext, cancellationToken) =>
            {
                if (BotDataHolderClass.listRelatedtologgedinUser.Contains(","))
                {
                    vmarraylist = BotDataHolderClass.listRelatedtologgedinUser.Split(",");
                }
                choices.Clear();

                if (vmarraylist.Length > 0)
                {

                    foreach (var arrayitem in vmarraylist)
                    {
                        string item = Regex.Replace(arrayitem, @"\s", "").Trim();
                        choices.Add(new Choice { Value = item });
                    }
                }
                else
                {
                    choices.Add(new Choice { Value = BotDataHolderClass.listRelatedtologgedinUser });
                }
                return await stepContext.PromptAsync(
                       "AssignmentChoicePrompt",
                       new PromptOptions
                       {
                           Prompt = stepContext.Context.Activity.CreateReply("Please click/choose any one of the following Assingments to know status: "),
                           Choices = choices,
                           RetryPrompt = stepContext.Context.Activity.CreateReply("Sorry, I did not understand that. Please choose any one from the options displayed below: "),

                       });
            });

            AddStep(async (stepContext, cancellationToken) =>
            {
                var response = (stepContext.Result as FoundChoice)?.Value;
                await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Selected{response}, Process to get the Status of selected Assingment has been initiated.. please wait..in mean time do not close or refresh or type anything"));
                return await stepContext.EndDialogAsync();


            });

        }
        public static new string Id => "Option2Dialog";

        public static Option2Dialog Instance { get; } = new Option2Dialog(Id);
    }
}
