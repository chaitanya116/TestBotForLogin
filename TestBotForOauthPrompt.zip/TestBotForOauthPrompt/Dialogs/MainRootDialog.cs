﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EchoBot.Dialogs
{
    public class MainRootDialog : ComponentDialog
    {
        private IStatePropertyAccessor<JObject> _userStateAccessor;     
   
        public MainRootDialog(UserState userState)
            : base("root")
        {
            _userStateAccessor = userState.CreateProperty<JObject>("result");
            AddDialog(Prompt(BotDataHolderClass.ConnectionName));            
            AddDialog(LoginDialog.Instance);
            AddDialog(DisplayOptionsDialog.Instance);
            AddDialog(Option2Dialog.Instance);
            AddDialog(Option3Dialog.Instance);
            AddDialog(Option4Dialog.Instance);
            AddDialog(Option5Dialog.Instance);
            AddDialog(LogOutDialog.Instance);
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ChoicePrompt("choicePrompt"));
            AddDialog(new ChoicePrompt("AssignmentChoicePrompt"));
            InitialDialogId = LoginDialog.Id;
        }

        private static OAuthPrompt Prompt(string connectionName)
        {
            return new OAuthPrompt(
               BotDataHolderClass.LoginPromptName,
               new OAuthPromptSettings
               {
                   ConnectionName = connectionName,
                   Text = "Please enter your credentials before you can proceed like \" john.doe@gmail.com\" : ",
                   Title = "SignIn",
                   Timeout = 300000, // User has 5 minutes to login (1000 * 60 * 5)
               });
        }

    }
}
