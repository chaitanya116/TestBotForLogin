﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.AI.QnA;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace EchoBot.Dialogs
{
    public class DisplayOptionsDialog : WaterfallDialog
    {
        public DisplayOptionsDialog(string dialogId, IEnumerable<WaterfallStep> steps = null)
             : base(dialogId, steps)
        {
            AddStep(async (stepContext, cancellationToken) =>
            {

                return await stepContext.PromptAsync(
                         "choicePrompt",
                         new PromptOptions
                         {
                             Prompt = stepContext.Context.Activity.CreateReply("Based on the access privileges assigned to you by your admin, below are the options you can avail. Please click/choose any one from the following: "),
                             Choices = new[] { new Choice { Value = "ViewMyAssignments" },new Choice { Value = "Option2" }, new Choice { Value = "Option3" }, new Choice { Value = "Option4" }, new Choice { Value = "Option5" }, new Choice { Value = "LogOut" } }.ToList(),
                             RetryPrompt = stepContext.Context.Activity.CreateReply("Sorry, I did not understand that. Please choose any one from the options displayed below: "),
                         });

            });

            AddStep(async (stepContext, cancellationToken) =>
            {
                var response = (stepContext.Result as FoundChoice)?.Value;
                if (response == "ViewMyAssignments")
                {
                    return await stepContext.BeginDialogAsync(Option2Dialog.Id, cancellationToken: cancellationToken);
                }
                if (response == "Option2")
                {
                    return await stepContext.BeginDialogAsync(Option3Dialog.Id, cancellationToken: cancellationToken);

                }
                else if (response == "Option3")
                {
                    return await stepContext.BeginDialogAsync(Option4Dialog.Id, cancellationToken: cancellationToken);

                }
                if (response == "Option4")
                {
                    return await stepContext.BeginDialogAsync(Option5Dialog.Id, cancellationToken: cancellationToken);

                }
                if (response == "LogOut")
                {
                    return await stepContext.BeginDialogAsync(LogOutDialog.Id, cancellationToken: cancellationToken);

                }
              
                
                return await stepContext.NextAsync();
            });
            AddStep(async (stepContext, cancellationToken) =>
            {
                return await stepContext.ReplaceDialogAsync(Id);
            });

        }

        public static new string Id => "DisplayOptionsDialog";     
        public static DisplayOptionsDialog Instance { get; set; } = new DisplayOptionsDialog(Id);


    }
}

